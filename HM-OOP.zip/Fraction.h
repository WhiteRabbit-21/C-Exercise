#pragma once

class Fraction
{
private:
	double numerator;
	double denominator;
public:
	Fraction();
	~Fraction();

	double GetValuesNum();

	double GetValuesDen();

	void ShowValues();

};


